<?php
	$serverUrl = "http://192.168.0.103/QrAtt/server"
?>

